
import React, { useState, useMemo } from 'react';
import ProfitCalculator from './components/ProfitCalculator';
import Dashboard from './components/Dashboard';
import VoiceAssistant from './components/VoiceAssistant';
import { FinancialData, MarginResults } from './types';

const App: React.FC = () => {
  const [data, setData] = useState<FinancialData>({
    revenue: 100000,
    cogs: 60000,
    operatingExpenses: 25000,
    taxRate: 21,
  });

  const [showInstallHelp, setShowInstallHelp] = useState(false);

  const results = useMemo<MarginResults>(() => {
    const grossProfit = data.revenue - data.cogs;
    const grossMargin = data.revenue > 0 ? (grossProfit / data.revenue) * 100 : 0;
    
    const operatingProfit = grossProfit - data.operatingExpenses;
    const operatingMargin = data.revenue > 0 ? (operatingProfit / data.revenue) * 100 : 0;
    
    const taxes = operatingProfit > 0 ? operatingProfit * (data.taxRate / 100) : 0;
    const netProfit = operatingProfit - taxes;
    const netMargin = data.revenue > 0 ? (netProfit / data.revenue) * 100 : 0;

    return {
      grossProfit,
      grossMargin,
      operatingProfit,
      operatingMargin,
      netProfit,
      netMargin,
    };
  }, [data]);

  const handlePrint = () => {
    window.print();
  };

  const formatCurrency = (val: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);
  const currentDate = new Date().toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <div className="min-h-screen pb-32">
      {/* Printable Receipt Section */}
      <div className="print-only receipt-container">
        <div className="watermark">OFFICIAL FINANCIAL REPORT</div>
        
        <div className="border-b-2 border-slate-900 pb-8 mb-8 flex justify-between items-end">
          <div>
            <h1 className="text-4xl font-black text-slate-900 tracking-tighter uppercase">MarginMaster</h1>
            <p className="text-sm font-bold text-slate-500 tracking-[0.2em] uppercase">Enterprise Financial Audit</p>
          </div>
          <div className="text-right">
            <p className="text-xs font-bold text-slate-400 uppercase">Generated On</p>
            <p className="text-sm font-mono">{currentDate}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-12 mb-12">
          <div className="space-y-4">
            <h3 className="text-xs font-black text-slate-900 uppercase border-b border-slate-200 pb-2">Revenue Streams</h3>
            <div className="flex justify-between">
              <span className="text-slate-600">Total Gross Revenue</span>
              <span className="font-mono font-bold">{formatCurrency(data.revenue)}</span>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-xs font-black text-slate-900 uppercase border-b border-slate-200 pb-2">Cost Analysis</h3>
            <div className="flex justify-between">
              <span className="text-slate-600">Cost of Goods Sold (COGS)</span>
              <span className="font-mono">{formatCurrency(data.cogs)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Operating Expenses</span>
              <span className="font-mono">{formatCurrency(data.operatingExpenses)}</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-slate-100">
              <span className="font-bold">Total Expenses</span>
              <span className="font-mono font-bold">{formatCurrency(data.cogs + data.operatingExpenses)}</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-50 p-8 rounded-xl border border-slate-200 mb-12">
          <h3 className="text-xs font-black text-slate-900 uppercase mb-6 text-center tracking-widest">Profitability Summary</h3>
          <div className="grid grid-cols-3 gap-8 text-center">
            <div>
              <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Gross Margin</p>
              <p className="text-2xl font-black text-indigo-600">{results.grossMargin.toFixed(2)}%</p>
              <p className="text-xs font-mono text-slate-500 mt-1">{formatCurrency(results.grossProfit)}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Operating Margin</p>
              <p className="text-2xl font-black text-purple-600">{results.operatingMargin.toFixed(2)}%</p>
              <p className="text-xs font-mono text-slate-500 mt-1">{formatCurrency(results.operatingProfit)}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Net Margin</p>
              <p className="text-2xl font-black text-pink-600">{results.netMargin.toFixed(2)}%</p>
              <p className="text-xs font-mono text-slate-500 mt-1">{formatCurrency(results.netProfit)}</p>
            </div>
          </div>
        </div>

        <div className="text-center mt-24 pt-8 border-t border-slate-100 italic text-slate-400 text-xs">
          This document is an automatically generated financial analysis report from MarginMaster AI. 
          Confidential and Proprietary. All calculations based on user-provided data inputs.
        </div>
      </div>

      {/* Main UI Header */}
      <header className="no-print sticky top-0 z-40 bg-white/70 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 7h-9"/><path d="M14 17H5"/><circle cx="17" cy="17" r="3"/><circle cx="7" cy="7" r="3"/></svg>
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">MarginMaster</h1>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Enterprise Analyzer</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowInstallHelp(true)}
              className="bg-indigo-50 text-indigo-600 p-2 rounded-lg hover:bg-indigo-100 transition-colors"
              title="App Help"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>
            </button>
            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${results.netMargin > 15 ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
              {results.netMargin > 15 ? 'Healthy' : 'Needs Optimization'}
            </span>
          </div>
        </div>
      </header>

      {/* APK Help Modal */}
      {showInstallHelp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm no-print">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 animate-in zoom-in duration-200">
            <div className="flex justify-between items-start mb-6">
              <h3 className="text-2xl font-bold text-slate-900">How to install as APK</h3>
              <button onClick={() => setShowInstallHelp(false)} className="text-slate-400 hover:text-slate-600">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
              </button>
            </div>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-sm">1</div>
                <p className="text-slate-600 text-sm">Copy the URL of this website.</p>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-sm">2</div>
                <p className="text-slate-600 text-sm">Visit <span className="font-bold text-indigo-600">PWABuilder.com</span> on your phone or PC.</p>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-sm">3</div>
                <p className="text-slate-600 text-sm">Paste the URL and click "Package for Android".</p>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-sm">4</div>
                <p className="text-slate-600 text-sm">Download the ZIP, extract it, and install the <span className="font-bold">.apk</span> file.</p>
              </div>
            </div>
            <button 
              onClick={() => setShowInstallHelp(false)}
              className="w-full mt-8 bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
            >
              Got it!
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="no-print max-w-5xl mx-auto px-4 pt-8 space-y-8">
        <section>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">Financial Performance</h2>
              <p className="text-slate-500 text-sm">Real-time breakdown of your business profitability.</p>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={handlePrint}
                className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-xl text-sm font-bold active:scale-95 shadow-lg shadow-slate-200"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 9V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v5"/><rect width="12" height="8" x="6" y="14" rx="1"/></svg>
                Export PDF
              </button>
              <button 
                onClick={() => setData({ revenue: 0, cogs: 0, operatingExpenses: 0, taxRate: 21 })}
                className="px-4 py-2 text-sm font-semibold text-slate-600 hover:text-indigo-600 transition-colors"
              >
                Reset
              </button>
            </div>
          </div>
          
          <Dashboard results={results} />
        </section>

        <section>
          <ProfitCalculator data={data} onChange={setData} />
        </section>

        <section className="bg-slate-900 rounded-3xl p-8 text-white relative overflow-hidden">
          <div className="relative z-10 max-w-2xl">
            <h3 className="text-2xl font-bold mb-4">Strategic Voice Insights</h3>
            <p className="text-slate-400 mb-6 text-sm leading-relaxed">
              Analyze "what-if" scenarios or tax implications with our AI business expert. 
              The advisor has real-time access to your currently input figures.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700">
                <p className="text-[10px] uppercase font-bold text-slate-500 mb-1">Current Revenue</p>
                <p className="text-xl font-mono font-bold">${data.revenue.toLocaleString()}</p>
              </div>
              <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700">
                <p className="text-[10px] uppercase font-bold text-slate-500 mb-1">Efficiency Ratio</p>
                <p className="text-xl font-mono font-bold">{(data.cogs / data.revenue || 0).toFixed(2)}</p>
              </div>
              <button 
                onClick={() => setShowInstallHelp(true)}
                className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold text-sm hover:bg-indigo-500 transition-colors flex items-center gap-2 shadow-xl shadow-indigo-900/40"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                Install Native App
              </button>
            </div>
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/20 rounded-full blur-3xl -mr-20 -mt-20"></div>
          <div className="absolute bottom-0 right-0 w-48 h-48 bg-pink-600/10 rounded-full blur-3xl -mr-10 -mb-10"></div>
        </section>
      </main>

      {/* Voice Assistant Overlay */}
      <div className="no-print">
        <VoiceAssistant financialData={data} results={results} />
      </div>
    </div>
  );
};

export default App;
