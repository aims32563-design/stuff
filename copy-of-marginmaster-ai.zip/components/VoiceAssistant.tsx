
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';
import { FinancialData, MarginResults, TranscriptionItem } from '../types';
import { createBlob, decode, decodeAudioData } from '../services/audioUtils';

interface Props {
  financialData: FinancialData;
  results: MarginResults;
}

const VoiceAssistant: React.FC<Props> = ({ financialData, results }) => {
  const [status, setStatus] = useState<'idle' | 'requesting' | 'active' | 'error'>('idle');
  const [transcriptions, setTranscriptions] = useState<TranscriptionItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const transcriptionRef = useRef({ user: '', model: '' });

  const startAssistant = async () => {
    setStatus('requesting');
    setError(null);

    try {
      // Explicitly request microphone access first
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          inputAudioTranscription: {},
          systemInstruction: `You are a world-class business financial advisor. Help the user analyze their profit margins. 
          Current business data: 
          - Revenue: $${financialData.revenue}
          - COGS: $${financialData.cogs}
          - Operating Expenses: $${financialData.operatingExpenses}
          - Tax Rate: ${financialData.taxRate}%
          - Gross Margin: ${results.grossMargin.toFixed(2)}%
          - Net Margin: ${results.netMargin.toFixed(2)}%
          Be concise, professional, and offer actionable advice based on these specific numbers.`,
        },
        callbacks: {
          onopen: () => {
            if (!audioContextRef.current) return;
            
            const source = audioContextRef.current.createMediaStreamSource(stream);
            const scriptProcessor = audioContextRef.current.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current.destination);
            setStatus('active');
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.inputTranscription) {
              transcriptionRef.current.user += message.serverContent.inputTranscription.text;
            }
            if (message.serverContent?.outputTranscription) {
              transcriptionRef.current.model += message.serverContent.outputTranscription.text;
            }

            if (message.serverContent?.turnComplete) {
              const u = transcriptionRef.current.user;
              const m = transcriptionRef.current.model;
              if (u || m) {
                setTranscriptions(prev => [
                  ...prev,
                  { text: u || '(Audio input)', sender: 'user', timestamp: Date.now() },
                  { text: m || '(Audio response)', sender: 'assistant', timestamp: Date.now() + 1 }
                ].slice(-6));
              }
              transcriptionRef.current = { user: '', model: '' };
            }

            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && outputAudioContextRef.current) {
              const audioCtx = outputAudioContextRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, audioCtx.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), audioCtx, 24000, 1);
              
              const source = audioCtx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(audioCtx.destination);
              source.onended = () => sourcesRef.current.delete(source);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => {
                try { s.stop(); } catch(e) {}
              });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error('Live API Error:', e);
            setError('AI Connection error.');
            stopAssistant();
          },
          onclose: () => {
            setStatus('idle');
          }
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err: any) {
      console.error('Failed to start assistant:', err);
      setStatus('error');
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setError('Microphone access denied. Please check settings.');
      } else if (err.message?.includes('dismissed')) {
        setError('Permission prompt was closed. Please try again.');
      } else {
        setError('Microphone error: ' + (err.message || 'Unknown error'));
      }
    }
  };

  const stopAssistant = () => {
    if (sessionRef.current) {
      try { sessionRef.current.close(); } catch(e) {}
      sessionRef.current = null;
    }
    if (audioContextRef.current) {
      try { audioContextRef.current.close(); } catch(e) {}
      audioContextRef.current = null;
    }
    if (outputAudioContextRef.current) {
      try { outputAudioContextRef.current.close(); } catch(e) {}
      outputAudioContextRef.current = null;
    }
    sourcesRef.current.forEach(s => {
      try { s.stop(); } catch(e) {}
    });
    sourcesRef.current.clear();
    setStatus('idle');
  };

  const isActive = status === 'active';
  const isRequesting = status === 'requesting';

  return (
    <div className="fixed bottom-0 left-0 right-0 p-4 z-50 pointer-events-none">
      <div className="max-w-4xl mx-auto flex flex-col items-end pointer-events-auto">
        {(isActive || isRequesting) && (
          <div className="bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-slate-200 mb-4 w-full max-w-sm overflow-hidden animate-in slide-in-from-bottom duration-300">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex gap-1">
                <span className={`w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce ${isRequesting ? 'opacity-50' : ''}`}></span>
                <span className={`w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce delay-150 ${isRequesting ? 'opacity-50' : ''}`}></span>
                <span className={`w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce delay-300 ${isRequesting ? 'opacity-50' : ''}`}></span>
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                {isRequesting ? 'Initializing...' : 'Advisor Live'}
              </span>
            </div>
            <div className="space-y-3 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
              {transcriptions.length === 0 && !isRequesting && (
                <p className="text-sm text-slate-400 italic">Listening to your financial queries...</p>
              )}
              {isRequesting && (
                <p className="text-sm text-slate-600">Please allow microphone access when prompted.</p>
              )}
              {transcriptions.map((t, i) => (
                <div key={i} className={`flex flex-col ${t.sender === 'user' ? 'items-end' : 'items-start'}`}>
                  <span className="text-[10px] text-slate-400 mb-0.5">{t.sender === 'user' ? 'You' : 'Advisor'}</span>
                  <p className={`text-sm px-3 py-2 rounded-2xl ${t.sender === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-slate-100 text-slate-800 rounded-tl-none'}`}>
                    {t.text}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex items-center gap-3">
          {error && (
            <div className="bg-red-50 border border-red-100 px-4 py-2 rounded-xl shadow-sm flex items-center gap-2 animate-in fade-in zoom-in duration-200">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
              <span className="text-xs text-red-700 font-medium">{error}</span>
              <button onClick={() => setError(null)} className="text-red-400 hover:text-red-600 ml-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
              </button>
            </div>
          )}
          
          <button
            disabled={isRequesting}
            onClick={isActive ? stopAssistant : startAssistant}
            className={`flex items-center gap-2 p-4 rounded-full shadow-2xl transition-all active:scale-95 group ${
              isActive 
                ? 'bg-red-500 hover:bg-red-600 text-white' 
                : isRequesting
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white'
            }`}
          >
            {isActive ? (
              <>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/></svg>
                <span className="font-semibold pr-2">Stop Advisor</span>
              </>
            ) : isRequesting ? (
              <>
                <svg className="animate-spin h-5 w-5 text-slate-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                <span className="font-semibold pr-2">Connecting...</span>
              </>
            ) : (
              <>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>
                <span className="font-semibold pr-2">Consult via Voice</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default VoiceAssistant;
