
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { MarginResults } from '../types';

interface Props {
  results: MarginResults;
}

const Dashboard: React.FC<Props> = ({ results }) => {
  const chartData = [
    { name: 'Gross Margin', value: results.grossMargin, color: '#6366f1' },
    { name: 'Operating Margin', value: results.operatingMargin, color: '#8b5cf6' },
    { name: 'Net Margin', value: results.netMargin, color: '#ec4899' },
  ];

  const breakdownData = [
    { name: 'Profitability', gross: results.grossProfit, operating: results.operatingProfit, net: results.netProfit },
  ];

  const formatCurrency = (val: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-sm font-medium text-slate-500">Gross Profit</p>
          <p className="text-2xl font-bold text-slate-900">{formatCurrency(results.grossProfit)}</p>
          <div className="mt-2 text-sm text-indigo-600 font-semibold">{results.grossMargin.toFixed(1)}% Margin</div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-sm font-medium text-slate-500">Operating Profit</p>
          <p className="text-2xl font-bold text-slate-900">{formatCurrency(results.operatingProfit)}</p>
          <div className="mt-2 text-sm text-purple-600 font-semibold">{results.operatingMargin.toFixed(1)}% Margin</div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-sm font-medium text-slate-500">Net Profit</p>
          <p className="text-2xl font-bold text-slate-900">{formatCurrency(results.netProfit)}</p>
          <div className="mt-2 text-sm text-pink-600 font-semibold">{results.netMargin.toFixed(1)}% Margin</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 min-h-[300px]">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Margin Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={chartData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip cursor={{ fill: '#f1f5f9' }} />
              <Bar dataKey="value" name="Margin %">
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 min-h-[300px]">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Profit Layers</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
              <Legend verticalAlign="bottom" height={36} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
