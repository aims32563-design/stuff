
import React from 'react';
import { FinancialData } from '../types';

interface Props {
  data: FinancialData;
  onChange: (newData: FinancialData) => void;
}

const ProfitCalculator: React.FC<Props> = ({ data, onChange }) => {
  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onChange({
      ...data,
      [name]: parseFloat(value) || 0,
    });
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 space-y-6">
      <h2 className="text-xl font-semibold text-slate-800 flex items-center gap-2">
        <span className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2v20"/><path d="m17 5-5-3-5 3"/><path d="m17 19-5 3-5-3"/><path d="M2 12h20"/><path d="m5 17-3-5 3-5"/><path d="m19 17 3-5-3-5"/></svg>
        </span>
        Input Financial Data
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-600">Total Revenue ($)</label>
          <input
            type="number"
            name="revenue"
            value={data.revenue}
            onChange={handleInput}
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
            placeholder="0.00"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-600">COGS ($)</label>
          <input
            type="number"
            name="cogs"
            value={data.cogs}
            onChange={handleInput}
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
            placeholder="0.00"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-600">Operating Expenses ($)</label>
          <input
            type="number"
            name="operatingExpenses"
            value={data.operatingExpenses}
            onChange={handleInput}
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
            placeholder="0.00"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-600">Tax Rate (%)</label>
          <input
            type="number"
            name="taxRate"
            value={data.taxRate}
            onChange={handleInput}
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
            placeholder="0"
          />
        </div>
      </div>
    </div>
  );
};

export default ProfitCalculator;
