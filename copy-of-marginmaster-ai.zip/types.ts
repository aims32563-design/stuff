
export interface FinancialData {
  revenue: number;
  cogs: number; // Cost of Goods Sold
  operatingExpenses: number;
  taxRate: number;
}

export interface MarginResults {
  grossProfit: number;
  grossMargin: number;
  operatingProfit: number;
  operatingMargin: number;
  netProfit: number;
  netMargin: number;
}

export interface TranscriptionItem {
  text: string;
  sender: 'user' | 'assistant';
  timestamp: number;
}
